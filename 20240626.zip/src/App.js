// App이라는 자바스크립트 파일로 경로가 지정되어있기 때문에 css도 기본적으로 App.css
// 밑에 있는 useState 꼭 포함해야 사용 가능하다 (자동완성으로 가능)
import { useState } from 'react';
import './App.css';

function App() {
  // 변수 생성
  // "데이터 바인딩" : 변수를 html에 꽂아넣는 작업 → 중괄호 사용
  // ex) className={data}
  // let data = 'red';
  // let post = '신분당선 맛집';
  // let array = ['남자 코트 추천', '강남 우동맛집', '파이썬 독학'];
  // let array2 = ['kim', 20];

  // let name = array2[0];
  // let age = array2[1];
  // let [name, age] = ['kim', 20];

  // 따봉을 누르면 숫자를 기억해서 따봉수를 표현하고 싶다.
  // let like = 0;

  // 변수의 값은 변경 되지만 실제 리액트에서는 변경된 변수값을 html 코드에 적용을 하지 못한다.
  // useState('보관할 자료'); 이 함수를 이용해서 값을 저장하고 수정할 때 리액트가 감지할 수 있다.
  // let [변수명, 변수 수정하는 함수명] 
  // 일반 변수는 데이터 값은 변경 되지만 html에 적용이 안된다. 고정된 값을 저장할 때 
  // const num = 10;

  // 데이터를 변경해서 html에 보여줘야될 경우
  // useState() 사용한다.
  // let [likes, setLike] = useState([0, 0, 0]);

  // 일반 함수를 작성해서 사용할 수 있다.
  // 클릭 했을 때 공간의 번호를 받아온다.
  // function increment(index) {
  //   console.log(index);
  //   useState() 함수는 변경을 하면 안에 있는 모든 내용을 수정해버려서 기존에 있던 배열이 사라진다.

  //   기존에 있는 배열을 새로운 공간에 복사해서 다음에 수정하는 값을 저장하고 수정된 값 전체를 useState() 수정하는 곳에 저장한다.
  //   let newLikes = [...likes];
  //   newLikes[index]++;
  //   setLike(newLikes);
  // };

  let [글제목, 글제목변경] = useState(['여자 코트 추천', '강남 우동맛집', '파이썬 독학']);

  return (
    <div className="App">
      <button onClick={() => {
        // 글제목[0] = '남자코트 추천';

        let copy = [...글제목];
        if(copy[0] === '여자 코트 추천') {
          copy[0] = '남자 코트 추천';
        } else {
          copy[0] = '여자 코트 추천';
        }

        // 수정 버튼을 클릭했을 때 
        // 남자 코드 추천이면 여자 코트 추천 변경
        // 여자 코드 추천이면 남자 코트 추천 변경

        글제목변경(copy);
        console.log(글제목[0]);
      }}>
        수정버튼
      </button>

      <h1>{글제목[0]}</h1>



      {/* 따봉 수 올리기
      <div className='black-nav'>

        <div>ReactBlog</div>
      </div>

      <div className='list'>
        <h4>{array[0]} <span onClick={() => {
          스판태그를 눌렀을 때 like 변수를 변경 출력
          like++;
          setLike(likes[0] + 1); - 배열로는 안된다
          console.log(likes[0]);
          increment(0);
        }}>👍</span> {likes[0]}</h4>
        <p>2월 17일 발행</p>
        <p>{name}</p>
      </div>

      <div className='list'>
        <h4>{array[1]} <span onClick={() => {
          increment(1);
        }}>👍</span> {likes[1]}</h4>
        <p>2월 17일 발행</p>
      </div>

      <div className='list'>
        <h4>{array[2]} <span onClick={() => {
          increment(2);
        }}>👍</span> {likes[2]}</h4>
        <p>2월 17일 발행</p>
      </div> */}

      {/* react snippets 
      새로운 파일 만들 때 rfc 단축키 누르면 자동으로 함수를 만들어준다.
      */}

    </div>
  );
}

export default App;
