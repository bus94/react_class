import React, { useState } from 'react';
import './App.css';

export default function Modal() {
    let [글제목, 글제목변경] = useState(['여자 코트 추천', '강남 우동맛집', '파이썬 독학', '역삼역 집밥 추천']);

    // 모달창을 처음에는 안보였다가 버튼, 라벨, 따봉을 클릭했을 때 실행하기
    // let [box, setBox] = useState('닫힘');
    let [box, setBox] = useState(false);

    // // map() 사용방법
    // let 어레이 = [2, 3, 4];
    // // 어레이.map(function() {
    // //     console.log(1); 
    // // });
    // console.log(어레이);
    // let newArray = 어레이.map(function (a) {
    //     return a * 10;
    // })
    // console.log(newArray);

    return (
        <div>
            <div className='black-nav'>
                <div>ReactBlog</div>
            </div>

            {/* 계속 list가 반복되어 나올 경우 반복문을 이용해서 줄일 수 있다.
            for 문은 JSX 중괄호 안에서 사용할 수 없다.

            map()

            */}

            {/* 특정함수를 만들어서 실행하기 - 실행 안됨
            {
                () => {
                    const ele = [];
                    for (let i = 0; i < 글제목.length; i++) {
                        ele.push(
                            <div className='list'>
                                <h4>{글제목[i]} <span onClick={() => {

                                }}>👍</span> 0</h4>
                                <p>2월 17일 발행</p>
                            </div>
                        );
                    }
                    return ele;
                }
            } */}

            {
                // 글제목 배열의 개수만큼 요소를 생성한다.
                // 배열의 값을 0번 부터 하나씩 data로써 꺼내어 function(data)에 저장한다.

                // foreach()문은 단순히 데이터를 가져와서 반복 (data 변수 자체를 수정하지 않는다)
                // - 데이터 가져와서 반복만 (가져오기만 함)
                // map()문은 데이터를 가져와서 반복하여 조건이나 html 코드로 변경해서 '글제목'이라는 데이터 배열 공간에 저장한다.
                // - 데이터 가져와서 반복하여 수정 (가져와서 수정해서 출력해줌)
                글제목.map(function (data) {
                    return (
                        <div className='list'>
                            <h4>{data} <span onClick={() => {

                            }}>👍</span> 0</h4>
                            <p>2월 17일 발행</p>
                        </div>
                    )
                })
            }

            {/* <div className='list'>
                <h4>{글제목[0]} <span onClick={() => {

                }}>👍</span> 0</h4>
                <p>2월 17일 발행</p>
            </div>

            <div className='list'>
                <h4>{글제목[1]} <span onClick={() => {

                }}>👍</span> 0</h4>
                <p>2월 17일 발행</p>
            </div>

            <div className='list'>
                <h4>{글제목[2]} <span onClick={() => {

                }}>👍</span> 0</h4>
                <p>2월 17일 발행</p>
            </div> */}

            {/* 
            box 변수값이 true이면 <Box></Box> 보이기 
                        false이면 아무것도 보여주지 않는다.

            JSX 안에서는 if ~ else 문법을 바로 사용할 수 없다.
            */}
            <br></br>
            <button onClick={() => {
                // 1. 버튼을 클릭했을 때 모달창
                // 2. 버튼을 한 번 더누르면 모달창이 안보인다 (토글)
                // 현재 box는 false 안보임
                // false 일 때는 true로 변경
                setBox(!box);
            }}>{글제목[0]}</button>

            {
                // 삼항연산자를 이용하여 box 를 이용하여 Box 컴포넌트 생성할지 결정
                box == true ? <Box></Box> : null
            }

            {/* <Box></Box>
            <Box /> */}
            {/* 위의 내용처럼 긴~ html을 한 단어로 깔금하게 치환해서 넣을 수 있는 문법이 제공된다. 이것을 하나의 단어로 만든 것
            : Component 컴포넌트
            
            리액트에서 동적으로 요소값을 만들 때
            1. html, css 미리 디자인 해놓는다.
            2. 데이터를 저장하는 내용 state 저장하기
            3. state에 따라서 어떻게 보일지 조건문이나 반복문 등을 이용해서 보이기            
            */}

            {/* {
                // 게시글 서버에서 게시글의 데이터를 받아와서 배열에 저장 후 배열의 개수만큼 자동으로 저장하거나 사진데이터를 장바구니 등등
                // 배열의 자료 개수만큼 map 내부 코드를 실행한다. 
                // 그 안의 return html 요소
                // [<div>안녕</div>, <div>안녕</div>, <div>안녕</div>] 로 출력
                [1, 2, 3].map(function () {
                    return (<div>안녕</div>)
                })
            } */}
        </div>
    )
}

// 새로운 함수를 만들 때는 현재 파일명과 동일한 함수 밖에 선언을 해야한다.
// 컴포넌트 예시
function Box() {
    return (
        <div className='modal'>
            <h4> 제목 </h4>
            <p> 날짜 </p>
            <p> 상세내용 </p>
        </div>
    );
}

// function List() {
//     return(
//         <div className='list'>
//             <h4>{글제목[0]} <span onClick={() => {

//             }}>👍</span> 0</h4>
//             <p>2월 17일 발행</p>
//         </div>
//     );
// }